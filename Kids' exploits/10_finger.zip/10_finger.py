import tkinter as tk
import customtkinter as ttk
# pip install customtkinter
from tkinter import CENTER, TOP
import time, random, os

class App():
    def __init__(self):
        self.path = os.path.abspath(__file__).removesuffix('10_finger.py')
        
        self.root = ttk.CTk()
        self.root.geometry('1080x720')
        self.root.title("10-Finger lernen")
        self.root.bind("<Escape>", lambda x: self.root.destroy())
        self.fullscreen = False
        self.root.bind('<F11>', lambda x: self.change_fullscreen())
        self.root.bind('<KeyPress>', self.decide_cw)
        self.surface()
        self.characters = ()
        self.radio_maker()
        
        self.generate(4)
        self.wpm = 0
        self.last_time = time.time()
    
    def change_fullscreen(self):
        self.root.attributes('-fullscreen', not self.fullscreen)
        self.fullscreen_hint.destroy()
        self.fullscreen = not self.fullscreen
    
    def get_words(self, words: str):
        return words.split('\n')
    
    def radio_maker(self):
        self.selected_training = tk.IntVar()
        self.radio_possible = (
                ('Home-row', 0, ('a','s','d','f','j','k','l','ö')),
                ('German home-row', 1, ('a','s','d','f','j','k','l','ö','ä')),
                ('Gh+lower row', 2, ('a','s','d','f','j','k','l','ö','ä','y','x','c','v','b','b','n','m')),
                ('Gh+upper row', 3, ('a','s','d','f','j','k','l','ö','ä','q','w','e','r','t','z','u','i','o','p','ü')),
                ('All characters', 4, ('a','s','d','f','j','k','l','ö','ä','q','w','e','r','t','z','u','i','o','p','ü','y','x','c','v','b','b','n','m')),
                ('All +uppercase', 5, self.uppercase(('a','s','d','f','j','k','l','ö','ä','q','w','e','r','t','z','u','i','o','p','ü','y','x','c','v','b','b','n','m'))),
                ('100 words', 6, self.get_words(open(f"{self.path}häufigste_wörter/100_häufigste_wörter.txt", 'r', encoding='utf-8').read())),
                ('1000 words', 7, self.get_words(open(f"{self.path}häufigste_wörter/1000_häufigste_wörter.txt", 'r', encoding='utf-8').read())))
        
        for i in range(len(self.radio_possible)):
            self.r = ttk.CTkRadioButton(
                self.cont2,
                text=self.radio_possible[i][0],
                value=self.radio_possible[i][1],
                variable=self.selected_training,
                command=self.reset
            )
            self.r.pack(fill='x', padx=5, pady=5)
        
        self.characters = self.radio_possible[self.selected_training.get()][2]
        self.show_current.set(self.characters)
    
    def uppercase(self, characters: tuple):
        for i in characters:
            try:
                characters = characters + tuple(i.upper())
            except:
                pass
        return characters
    
    def surface(self):   
        self.cont = ttk.CTkFrame(self.root, border_width=5, width=500)
        self.cont.place(relx=0.5, rely=0.5, anchor=CENTER)
        
        self.show_current = tk.StringVar()
        self.possible_text = ttk.CTkLabel(master=self.root, height=20, textvariable=self.show_current, wraplength=self.root.winfo_screenmmwidth())
        self.possible_text.place(relx=0.5, anchor='n')
        
        self.var = ttk.StringVar()
        self.next_text = ttk.CTkLabel(master=self.cont, height=20, textvariable=self.var, font=('Times New Roman', 60))
        self.next_text.place(relx=0.5, rely=0.5, anchor='w')
        
        self.counter_var = ttk.IntVar()
        self.counter_var.set(0)
        self.counter = ttk.CTkLabel(master=self.root,textvariable=self.counter_var)
        self.counter.place(relx=1,rely=0,anchor='ne')
        
        self.wpm_var = ttk.StringVar()
        self.wpm_var.set('0 wpm')
        self.wpm_label = ttk.CTkLabel(master=self.root,textvariable=self.wpm_var)
        self.wpm_label.place(relx=1,rely=0,y=20,anchor='ne')
        
        self.alltime_correct = 0
        self.precison_var = ttk.StringVar()# TODO rather a string, gets updated by regular
        self.precison_var.set('1000.0% correct')
        self.precise = ttk.CTkLabel(master=self.root,textvariable=self.precison_var)
        self.precise.place(relx=1,y=40,anchor='ne')
        
        self.cont2 = ttk.CTkFrame(master=self.root)
        self.cont2.place(relx=0,rely=0.5, anchor='w')
        
        self.reset_button = ttk.CTkButton(master=self.cont, text='(Re)Set', command=self.reset)
        self.reset_button.place(relx=0.5, rely=1, anchor='s', y=-self.cont._border_width)
        
        self.fullscreen_hint = ttk.CTkLabel(master=self.root, text='Press F11 to toggle fullscreen')
        self.fullscreen_hint.place(relx=0.5, rely=1,anchor='s')
    
    def calc_precision(self):
        self.alltime_correct += 1
        self.precison_var.set(f'{round(self.counter_var.get()/self.alltime_correct*100,1)}% correct')
    
    def decide_cw(self, event):
        if self.selected_training.get() < 6:
            self.logic_c(event)
        else:
            self.logic_w(event)
    
    def logic_c(self, event):
        if event.char == self.var.get()[0]:
            self.var.set(self.var.get()[3:])
            self.generate_characters(1)
            self.correct()
        elif event.char in self.characters:
            self.mistake()
    
    def logic_w(self, event):
        if event.char == self.var.get()[0]:
            if self.var.get()[0] == ' ':
                self.generate_words(1)
                self.correct()
            else:
                self.correct(calc_wpm=False)
            self.var.set(self.var.get()[1:])
        elif event.char in self.radio_possible[5][2] or event.char == (' '):
            self.mistake()
    
    def correct(self, calc_wpm: bool=True):
        self.counter_var.set(self.counter_var.get()+1)
        self.cont.configure(border_color='green')
        if calc_wpm:
            temp = time.time()
            temp2 = temp-self.last_time
            percent = temp2/15
            self.wpm = (self.wpm-(self.wpm*percent))+1
            self.wpm_var.set(f'{int(self.wpm*4)} wpm')
            self.last_time = temp
        
        self.calc_precision()
    
    def mistake(self):
        self.cont.configure(border_color='red')
        self.calc_precision()
    
    def generate(self, amount):
        if self.selected_training.get() < 6:
        # if words == False:
            return self.generate_characters(amount)
        else:
            return self.generate_words(amount)
    
    def generate_characters(self, amount):
        for i in range(amount):
            self.var.set(self.var.get()+random.choice(self.radio_possible[self.selected_training.get()][2])+'  ')
    
    
    def generate_words(self, amount):
        # self.get_words()
        
        for i in range(amount):
            self.var.set(self.var.get()+random.choice(self.radio_possible[self.selected_training.get()][2])+' ')
            pass
    
    def reset(self):
        self.var.set('')
        self.wpm_var.set('0 wpm')
        self.wpm = 0.0
        self.counter_var.set('0')
        self.precison_var.set('100.0% correct')
        self.alltime_correct = 0
        self.cont.configure(border_color='gray27')
        self.characters = self.radio_possible[self.selected_training.get()][2]
        if self.selected_training.get() < 6:
            self.show_current.set(self.characters)
        else:
            self.show_current.set('Die häufigsten Worte der deutschen Sprache')
        self.generate(4)
        self.last_time = time.time()
    
    def run(self):
        self.root.mainloop()

if __name__ == '__main__':
    app = App()
    app.run()